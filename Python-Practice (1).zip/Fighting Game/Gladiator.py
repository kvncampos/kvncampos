import random

def fight(answernumber):
    if answernumber == 1:
        return "You died."
    elif answernumber == 2:
        return "You found loot."
    elif answernumber == 3:
        return "Nothin happened."

try:
    name = input("Enter fighters name. ")
except:
    print(f"Try again.")
    print(name)

print(f"Welcome {name.title()}. Fight vs Lvl 1. Starts NOW!")

choice = input()

if int(choice) > random.randint(1, 3):
    print(fight(int(choice)))
    print("You Won!")

elif int(choice) < random.randint(1,3):
    print("You lose.")

elif int(choice) == random.randint(1, 3):
    print(f"Equal damage taken. Null Effect.)
    

